/*using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; // UI Image kullanacaksan bu gerekli!
using TMPro;

public class MainGamePlay : MonoBehaviour
{

    private int sayac = 0;

   [Header("CharFoto")]
    public GameObject lvl1Char;
    public GameObject lvl2Char; 
    public GameObject lvl3Char;
    public GameObject lvl4Char;
    public GameObject lvl5Char;
    public GameObject lvl6Char;


    [Header("Player Data")]
    public PlayerData playerData;
    public int playerID;

    [Header("Profile Panel")]
    public TextMeshProUGUI seviye;
    public TextMeshProUGUI ULPuan;
    public TextMeshProUGUI OynamaSuresi;
    public GameObject profilPrefab;
    private GameObject profilPanel;
    private Button cikisButton;

    [Header("Kingdom Panel")]
    public GameObject kralligimPrefab;
    private GameObject kralligimPanel;
    public int kingdomID;
    public GameObject lvl1kingdom;
    public GameObject lvl2kingdom;
    public GameObject lvl3kingdom;  
    public GameObject lvl4kingdom;
    public GameObject lvl5kingdom;  
    public GameObject lvl6kingdom;
    private Button kingdomButton;

    void Start()
    {

        playerData = GameObject.Find("GameData").GetComponent<PlayerData>();
        playerID = playerData.playerID;
        kingdomID = playerData.kingdomID;

        seviye = profilPrefab.transform.Find("Canvas/Image/Image/SeviyeText").GetComponent<TextMeshProUGUI>();
        ULPuan = profilPrefab.transform.Find("Canvas/Image/Image/ULPuan").GetComponent<TextMeshProUGUI>();
        OynamaSuresi = profilPrefab.transform.Find("Canvas/Image/Image/OynamaSure").GetComponent<TextMeshProUGUI>();
        //lvl1kingdom = transform.Find("KingdomPanel/KingdomText"); 
    
        if(playerData.playerID == 0)
        {
            lvl1Char.SetActive(true); // lvl1 karakterini aktif et
            seviye.text = "Seviye : 0";
            ULPuan.text = "UL Puan : 1500";
            OynamaSuresi.text = "Oynama Süresi : 0h";
            

        }
        else if(playerID == 1)
        {
            lvl2Char.SetActive(true); // lvl1 karakterini pasif et
            seviye.text = "Seviye : 10";
            ULPuan.text = "UL Puan : 2500";
            OynamaSuresi.text = "Oynama Süresi : 2h";
            
        }
        else if(playerID == 2)
        {
            lvl3Char.SetActive(true); 
            seviye.text = "Seviye : 20";
            ULPuan.text = "UL Puan : 3500";
            OynamaSuresi.text = "Oynama Süresi : 5h";
              
            
            
        }
        else if(playerID == 3)
        {
            lvl4Char.SetActive(true); 
            seviye.text = "Seviye : 30";
            ULPuan.text = "UL Puan : 4500";
            OynamaSuresi.text = "Oynama Süresi : 10h";
            
           
        }
        else if(playerID == 4)
        {
            lvl5Char.SetActive(true); 
            seviye.text = "Seviye : 40";
            ULPuan.text = "UL Puan : 5500";
            OynamaSuresi.text = "Oynama Süresi : 20h";
             
            
        }
        else if(playerID == 5)
        {
            lvl6Char.SetActive(true); 
            seviye.text = "Seviye : 50";
            ULPuan.text = "UL Puan : 6500";
            OynamaSuresi.text = "Oynama Süresi : 30h";
            
           
        }
    }


    public void Cikis(){
        sayac = 0;
        Destroy(profilPanel);
    }

    public void Profil(){
        if(sayac == 0){
        profilPanel = Instantiate(profilPrefab);
        cikisButton = profilPanel.transform.Find("Canvas/Image/Image/CikisButton").GetComponent<Button>();
        cikisButton.onClick.AddListener(Cikis); 
        sayac = 1;
        }
    }
    
    public void Kralligim(){
        if(sayac == 0){
        kralligimPanel = Instantiate(kralligimPrefab);
        kingdomButton = KralligimPanaltransform.Find("Canvas/Image/Image/kingdomButton").GetComponent<Button>();
        kingdomButton.onClick.AddListener(kingdom); 
        sayac = 1;
        }
    
    }
        

    // Prefabı sahneye instantiate et
    kralligimPanel = Instantiate(kralligimPrefab);
    Debug.Log("✅ Kralligim panel açildi!");
    
    // Krallık objelerini prefab içinden bul
    lvl1kingdom = kralligimPanel.transform.Find("Canvas/Image/lvl1kingdom")?.gameObject;
    lvl2kingdom = kralligimPanel.transform.Find("Canvas/Image/lvl2kingdom")?.gameObject;
    lvl3kingdom = kralligimPanel.transform.Find("Canvas/Image/lvl3kingdom")?.gameObject;
    lvl4kingdom = kralligimPanel.transform.Find("Canvas/Image/lvl4kingdom")?.gameObject;
    lvl5kingdom = kralligimPanel.transform.Find("Canvas/Image/lvl5kingdom")?.gameObject;
    lvl6kingdom = kralligimPanel.transform.Find("Canvas/Image/lvl6kingdom")?.gameObject;

    // Önce hepsini kapat
    lvl1kingdom.SetActive(false);
    lvl2kingdom.SetActive(false);
    lvl3kingdom.SetActive(false);
    lvl4kingdom.SetActive(false);
    lvl5kingdom.SetActive(false);
    lvl6kingdom.SetActive(false);

    // Oyuncunun kingdomID'sine göre doğru görseli aç
    switch (kingdomID)
    {
        case 0: lvl1kingdom.SetActive(true); break;
        case 1: lvl2kingdom.SetActive(true); break;
        case 2: lvl3kingdom.SetActive(true); break;
        case 3: lvl4kingdom.SetActive(true); break;
        case 4: lvl5kingdom.SetActive(true); break;
        case 5: lvl6kingdom.SetActive(true); break;
        default:
            Debug.LogWarning("⚠️ Gecersiz kingdomID: " + kingdomID);
            break;
    }
}
*/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class MainGamePlay : MonoBehaviour
{
    private bool profilAcilmis = false;
    private bool kralligimAcilmis = false;
    private bool gorevlerimAcilmis = false;
    private bool gelisimAcilmis = false;

    [Header("CharFoto")]
    public GameObject lvl1Char;
    public GameObject lvl2Char;
    public GameObject lvl3Char;
    public GameObject lvl4Char;
    public GameObject lvl5Char;
    public GameObject lvl6Char;

    [Header("Player Data")]
    public PlayerData playerData;
    public int playerID;

    [Header("Profile Panel")]
    public GameObject profilPrefab;
    private GameObject profilPanel;
    private Button cikisButton;
    private TextMeshProUGUI seviye;
    private TextMeshProUGUI ULPuan;
    private TextMeshProUGUI OynamaSuresi;

    [Header("Kingdom Panel")]
    public GameObject kralligimPrefab;
    private GameObject kingdomPanel;
    public int kingdomID;
    private Button kingdomButton;
    private Button cikButton;
    
    

    private GameObject lvl1kingdom;
    private GameObject lvl2kingdom;
    private GameObject lvl3kingdom;
    private GameObject lvl4kingdom;
    private GameObject lvl5kingdom;
    private GameObject lvl6kingdom;

    [Header("Gorevlerim Panel")]
    public GameObject gorevlerimPrefab;
    private GameObject gorevlerimPanel;
    private Button gorevButton;
    private Button cikissButton;

    private GameObject gorev;
    private TextMeshProUGUI text;
    private TextMeshProUGUI text2;
    private TextMeshProUGUI text3;
    private TextMeshProUGUI text4;
    private TextMeshProUGUI text5;

    [Header("Gelisim Panel")]
    public GameObject gelisimPrefab;
    private GameObject gelisimPanel;    
    private Button gelisimButton;
    private Button cikisssButton;

    private GameObject gorevG;
    private TextMeshProUGUI textG;
    private TextMeshProUGUI text2G;
    private TextMeshProUGUI text3G; 
    private TextMeshProUGUI text4G;


    void Start()
    {
        // PlayerData objesini bul
        playerData = GameObject.Find("GameData").GetComponent<PlayerData>();
        playerID = playerData.playerID;
        kingdomID = playerData.kingdomID;

        // Oyuncuya uygun karakteri göster
        KarakterYukle();
    }

    // Karakteri ve bilgilerini ayarlayan fonksiyon
    void KarakterYukle()
    {
        /* // Önce tüm karakterleri kapat
        lvl1Char.SetActive(false);
        lvl2Char.SetActive(false);
        lvl3Char.SetActive(false);
        lvl4Char.SetActive(false);
        lvl5Char.SetActive(false);
        lvl6Char.SetActive(false);*/

        switch (playerID)
        {
            case 0:
                lvl1Char.SetActive(true);
                break;
            case 1:
                lvl2Char.SetActive(true);
                break;
            case 2:
                lvl3Char.SetActive(true);
                break;
            case 3:
                lvl4Char.SetActive(true);
                break;
            case 4:
                lvl5Char.SetActive(true);
                break;
            case 5:
                lvl6Char.SetActive(true);
                break;
            default:
                Debug.LogWarning("⚠️ Geçersiz playerID: " + playerID);
                break;
        }
    }

    // Profil panelini açar
    public void Profil()
    {
        if (profilAcilmis) return;

        profilPanel = Instantiate(profilPrefab);
        profilAcilmis = true;

        // Buton ve metinleri bul
        cikisButton = profilPanel.transform.Find("Canvas/Image/Image/CikisButton").GetComponent<Button>();
        seviye = profilPanel.transform.Find("Canvas/Image/Image/SeviyeText").GetComponent<TextMeshProUGUI>();
        ULPuan = profilPanel.transform.Find("Canvas/Image/Image/ULPuan").GetComponent<TextMeshProUGUI>();
        OynamaSuresi = profilPanel.transform.Find("Canvas/Image/Image/OynamaSure").GetComponent<TextMeshProUGUI>();

        // Buton işlevi
        cikisButton.onClick.AddListener(CikisProfil);

        // Oyuncu bilgilerini doldur
        switch (playerID)
        {
            case 0:
                seviye.text = "Seviye : 0";
                ULPuan.text = "UL Puan : 1500";
                OynamaSuresi.text = "Oynama Süresi : 0h";
                break;
            case 1:
                seviye.text = "Seviye : 10";
                ULPuan.text = "UL Puan : 2500";
                OynamaSuresi.text = "Oynama Süresi : 2h";
                break;
            case 2:
                seviye.text = "Seviye : 20";
                ULPuan.text = "UL Puan : 3500";
                OynamaSuresi.text = "Oynama Süresi : 5h";
                break;
            case 3:
                seviye.text = "Seviye : 30";
                ULPuan.text = "UL Puan : 4500";
                OynamaSuresi.text = "Oynama Süresi : 10h";
                break;
            case 4:
                seviye.text = "Seviye : 40";
                ULPuan.text = "UL Puan : 5500";
                OynamaSuresi.text = "Oynama Süresi : 20h";
                break;
            case 5:
                seviye.text = "Seviye : 50";
                ULPuan.text = "UL Puan : 6500";
                OynamaSuresi.text = "Oynama Süresi : 30h";
                break;
        }

        Debug.Log("✅ Profil paneli açildi!");
    }

    // Profil panelini kapatır
    public void CikisProfil()
    {
        if (profilPanel != null)
            Destroy(profilPanel);

        profilAcilmis = false;
        Debug.Log("❌ Profil paneli kapatildi!");
    }

    // Krallığım panelini açar
    public void Kralligim()
    {
        if (kralligimAcilmis) return;

        kingdomPanel = Instantiate(kralligimPrefab);
        kralligimAcilmis = true;
        Debug.Log("✅ Kralliğim paneli açildi!");
        cikButton.onClick.AddListener(CikKralligim);

        // Krallık objelerini prefab içinden bul
        lvl1kingdom = kingdomPanel.transform.Find("Canvas/Image/lvl1kingdom")?.gameObject;
        lvl2kingdom = kingdomPanel.transform.Find("Canvas/Image/lvl2kingdom")?.gameObject;
        lvl3kingdom = kingdomPanel.transform.Find("Canvas/Image/lvl3kingdom")?.gameObject;
        lvl4kingdom = kingdomPanel.transform.Find("Canvas/Image/lvl4kingdom")?.gameObject;
        lvl5kingdom = kingdomPanel.transform.Find("Canvas/Image/lvl5kingdom")?.gameObject;
        lvl6kingdom = kingdomPanel.transform.Find("Canvas/Image/lvl6kingdom")?.gameObject;

        // Hepsini kapat
        lvl1kingdom?.SetActive(false);
        lvl2kingdom?.SetActive(false);
        lvl3kingdom?.SetActive(false);
        lvl4kingdom?.SetActive(false);
        lvl5kingdom?.SetActive(false);
        lvl6kingdom?.SetActive(false);

        // Oyuncunun kingdomID'sine göre doğru görseli aç
        switch (kingdomID)
        {
            case 0: lvl1kingdom?.SetActive(true); break;
            case 1: lvl2kingdom?.SetActive(true); break;
            case 2: lvl3kingdom?.SetActive(true); break;
            case 3: lvl4kingdom?.SetActive(true); break;
            case 4: lvl5kingdom?.SetActive(true); break;
            case 5: lvl6kingdom?.SetActive(true); break;
            default:
                Debug.LogWarning("⚠️ Geçersiz kingdomID: " + kingdomID);
                break;
        }

        // Çıkış butonu bağlama (isteğe bağlı)
        cikButton = kingdomPanel.transform.Find("Canvas/cikButton")?.GetComponent<Button>();
        if (cikButton != null)
            cikButton.onClick.AddListener(CikKralligim);
    }

    // Krallık panelini kapatır
    public void CikKralligim()
    {
        if (kingdomPanel != null)
            Destroy(kingdomPanel);

        kralligimAcilmis = false;
        Debug.Log("❌ Kralliğim paneli kapatildi!");
    }

    // Görevlerim panelini açar
    public void Gorevlerim()
    {
        if (gorevlerimAcilmis) return;

        gorevlerimPanel = Instantiate(gorevlerimPrefab);
        gorevlerimAcilmis = true;
        Debug.Log("✅ Gorevlerim paneli açildi!");
        cikissButton.onClick.AddListener(CikissGorevlerim);

        // Gorevlerim objelerini prefab içinden bul
        gorev = gorevlerimPanel.transform.Find("Canvas/Image/Image")?.gameObject;
        text = gorevlerimPanel.transform.Find("Canvas/Image/Text (TMP)")?.GetComponent<TextMeshProUGUI>();
        text2 = gorevlerimPanel.transform.Find("Canvas/Image/Text (TMP) (1)")?.GetComponent<TextMeshProUGUI>();
        text3 = gorevlerimPanel.transform.Find("Canvas/Image/Text (TMP) (2)")?.GetComponent<TextMeshProUGUI>();
        text4 = gorevlerimPanel.transform.Find("Canvas/Image/Text (TMP) (3)")?.GetComponent<TextMeshProUGUI>();
        text5 = gorevlerimPanel.transform.Find("Canvas/Image/Text (TMP) (4)")?.GetComponent<TextMeshProUGUI>();

        // Çıkış butonu bağlama (isteğe bağlı)
        cikissButton = gorevlerimPanel.transform.Find("Canvas/Image/CikissButton")?.GetComponent<Button>();
        if (cikissButton != null)
            cikissButton.onClick.AddListener(CikissGorevlerim);
    }

    // Krallık panelini kapatır
    public void CikissGorevlerim()
    {
        if (gorevlerimPanel != null)
            Destroy(gorevlerimPanel);

        gorevlerimAcilmis = false;
        Debug.Log("❌ Gorevlerim paneli kapatildi!");
    }


    // Gelisim panelini açar
    public void Gelisim()
    {
        if (gelisimAcilmis) return;

        gelisimPanel = Instantiate(gelisimPrefab);
        gelisimAcilmis = true;
        Debug.Log("✅ Gorevlerim paneli açildi!");
        cikisssButton.onClick.AddListener(CikisssGelisim);

        // Gorevlerim objelerini prefab içinden bul
        gorevG = gelisimPanel.transform.Find("Canvas/Image/Image")?.gameObject;
        textG = gelisimPanel.transform.Find("Canvas/Image/Image/Text (TMP)")?.GetComponent<TextMeshProUGUI>();
        text2G = gelisimPanel.transform.Find("Canvas/Image/Image/Text (TMP) (1)")?.GetComponent<TextMeshProUGUI>();
        text3G = gelisimPanel.transform.Find("Canvas/Image/Image/Text (TMP) (2)")?.GetComponent<TextMeshProUGUI>();
        text4G = gelisimPanel.transform.Find("Canvas/Image/Image/Text (TMP) (3)")?.GetComponent<TextMeshProUGUI>();
        

        // Çıkış butonu bağlama (isteğe bağlı)
        cikisssButton = gelisimPanel.transform.Find("Canvas/Image/CikisssButton")?.GetComponent<Button>();
        if (cikisssButton != null)
            cikisssButton.onClick.AddListener(CikisssGelisim);
    }

    // Krallık panelini kapatır
    public void CikisssGelisim()
    {
        if (gelisimPanel != null)
            Destroy(gelisimPanel);

        gelisimAcilmis = false;
        Debug.Log("❌ Gorevlerim paneli kapatildi!");
    }
}

/*
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; // UI Image kullanacaksan bu gerekli!
using TMPro;

public class MainGamePlay : MonoBehaviour
{

    private int sayac = 0;

   [Header("CharFoto")]
    public GameObject lvl1Char;
    public GameObject lvl2Char; 
    public GameObject lvl3Char;
    public GameObject lvl4Char;
    public GameObject lvl5Char;
    public GameObject lvl6Char;


    [Header("Player Data")]
    public PlayerData playerData;
    public int playerID;

    [Header("Profile Panel")]
    public TextMeshProUGUI seviye;
    public TextMeshProUGUI ULPuan;
    public TextMeshProUGUI OynamaSuresi;
    public GameObject profilPrefab;
    private GameObject profilPanel;
    private Button cikisButton;

    // YENİ EKLEME: Krallık paneli için gerekli değişkenler
    [Header("Kralligim Panel")]
    public GameObject kralligimPrefab; // Krallık Panelinin prefabı
    private GameObject kralligimPanel; // Açık paneli tutmak için

    [Header("Kingdom Panel")]
    public int kingdomID;
    // HATA DÜZELTİLDİ: 'gameObject' yerine 'GameObject'
    public GameObject lvl1kingdom;
    public GameObject lvl2kingdom;
    public GameObject lvl3kingdom;  
    public GameObject lvl4kingdom;
    public GameObject lvl5kingdom;  
    public GameObject lvl6kingdom;
    
    // YENİ EKLEME: Krallık butonunun referansı
    public Button krallikButonu; // Inspector'dan sürükle-bırak ile bu butona işlev atayacağız.

    void Start()
    {

        playerData = GameObject.Find("GameData").GetComponent<PlayerData>();
        playerID = playerData.playerID;
        kingdomID = playerData.kingdomID;

        // START HATASI GİDERİLDİ: Tüm karakterleri kapatma (mantıksal düzeltme)
        lvl1Char.SetActive(false);
        lvl2Char.SetActive(false);
        lvl3Char.SetActive(false);
        lvl4Char.SetActive(false);
        lvl5Char.SetActive(false);
        lvl6Char.SetActive(false);

        // YENİ EKLEME: Krallık butonuna işlev atama
        if (krallikButonu != null)
        {
            krallikButonu.onClick.AddListener(Kralligim);
        }

        // UI Text objelerini prefab içinden bulma kısmı çalışma zamanı hatası verebilir (korundu)
        // seviye = profilPrefab.transform.Find("Canvas/Image/Image/SeviyeText").GetComponent<TextMeshProUGUI>();
        // ULPuan = profilPrefab.transform.Find("Canvas/Image/Image/ULPuan").GetComponent<TextMeshProUGUI>();
        // OynamaSuresi = profilPrefab.transform.Find("Canvas/Image/Image/OynamaSure").GetComponent<TextMeshProUGUI>();

        if(playerData.playerID == 0)
        {
            lvl1Char.SetActive(true); // lvl1 karakterini aktif et
            seviye.text = "Seviye : 0";
            ULPuan.text = "UL Puan : 1500";
            OynamaSuresi.text = "Oynama Süresi : 0h";
            // Krallık objesi atama satırları Start() içinde olmamalı (kaldırıldı)
        }
        else if(playerID == 1)
        {
            lvl2Char.SetActive(true); 
            seviye.text = "Seviye : 10";
            ULPuan.text = "UL Puan : 2500";
            OynamaSuresi.text = "Oynama Süresi : 2h";
        }
        else if(playerID == 2)
        {
            lvl3Char.SetActive(true); 
            seviye.text = "Seviye : 20";
            ULPuan.text = "UL Puan : 3500";
            OynamaSuresi.text = "Oynama Süresi : 5h";
        }
        else if(playerID == 3)
        {
            lvl4Char.SetActive(true); 
            seviye.text = "Seviye : 30";
            ULPuan.text = "UL Puan : 4500";
            OynamaSuresi.text = "Oynama Süresi : 10h";
        }
        else if(playerID == 4)
        {
            lvl5Char.SetActive(true); 
            seviye.text = "Seviye : 40";
            ULPuan.text = "UL Puan : 5500";
            OynamaSuresi.text = "Oynama Süresi : 20h";
        }
        else if(playerID == 5)
        {
            lvl6Char.SetActive(true); 
            seviye.text = "Seviye : 50";
            ULPuan.text = "UL Puan : 6500";
            OynamaSuresi.text = "Oynama Süresi : 30h";
        }
    }


    public void Cikis(){
        sayac = 0;
        Destroy(profilPanel);
    }

    public void Profil(){
        if(sayac == 0){
        profilPanel = Instantiate(profilPrefab);
        // Hata: Start'ta bulmaya çalıştığınız Text objelerini burada da bulmanız gerekebilir. (Korundu)
        cikisButton = profilPanel.transform.Find("Canvas/Image/Image/CikisButton").GetComponent<Button>();
        cikisButton.onClick.AddListener(Cikis); 
        sayac = 1;
        }
    }
    
    // Kralligim metodunu Profil() dışına taşıdık. (Önceki düzeltmeden korundu)
    public void Kralligim(){
        // Paneli sadece bir kez Instantiate etmek daha iyidir, ancak kodunuzu koruyorum:
        kralligimPanel = Instantiate(kralligimPrefab);
        
        // Mantıksal Hata Düzeltmesi: Tüm krallıkları kapatmak (Null kontrolü eklendi)
        if (lvl1kingdom != null) lvl1kingdom.gameObject.SetActive(false);
        if (lvl2kingdom != null) lvl2kingdom.gameObject.SetActive(false);
        if (lvl3kingdom != null) lvl3kingdom.gameObject.SetActive(false);
        if (lvl4kingdom != null) lvl4kingdom.gameObject.SetActive(false);
        if (lvl5kingdom != null) lvl5kingdom.gameObject.SetActive(false);
        if (lvl6kingdom != null) lvl6kingdom.gameObject.SetActive(false);

        // Hata: lvlXkingdom referansları hala Start()'ta atanmaya çalışıldığı için burada Null olabilir. 
        // Eğer Inspector'dan atama yapmadıysanız NRE alırsınız. (Korundu)
        
        if(kingdomID == 0){
            if (lvl1kingdom != null) lvl1kingdom.gameObject.SetActive(true);
        }
        else if(kingdomID == 1){
            if (lvl2kingdom != null) lvl2kingdom.gameObject.SetActive(true);
        }
        else if(kingdomID == 2){
            if (lvl3kingdom != null) lvl3kingdom.gameObject.SetActive(true);
        }
        else if(kingdomID == 3){
            if (lvl4kingdom != null) lvl4kingdom.gameObject.SetActive(true);
        }
        else if(kingdomID == 4){
            if (lvl5kingdom != null) lvl5kingdom.gameObject.SetActive(true);
        }
        else if(kingdomID == 5){
            if (lvl6kingdom != null) lvl6kingdom.gameObject.SetActive(true);
        }
    }
}
*/