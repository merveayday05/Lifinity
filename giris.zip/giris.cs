using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class giris : MonoBehaviour
{
    public PlayerData PlayerDataObject;
    private TMP_InputField KullaniciAdi;
    private TMP_InputField Sifre;
    public GameObject self;
    // Start is called before the first frame update
    void Start()
    {

    }
    public void Cikis(){
        Destroy(self);
    }    

    public void GirisYap(){
        KullaniciAdi = transform.Find("Canvas/Image/KullaniciAdi").GetComponent<TMP_InputField>();
        Sifre = transform.Find("Canvas/Image/Sifre").GetComponent<TMP_InputField>();
        PlayerDataObject = GameObject.Find("GameData").GetComponent<PlayerData>();

           if(KullaniciAdi.text == "admin" && Sifre.text == "12345"){
            PlayerData.instance.playerID = 0; // lvl1 karakteri
            SceneManager.LoadScene("Main Game");
        }
        else if(KullaniciAdi.text == "user" && Sifre.text == "54321"){
            PlayerData.instance.playerID = 1;
            SceneManager.LoadScene("Main Game");
        }
        else if(KullaniciAdi.text == "player1" && Sifre.text == "11111"){
            PlayerData.instance.playerID = 2;
            SceneManager.LoadScene("Main Game");
        }
        else if(KullaniciAdi.text == "player2" && Sifre.text == "22222"){
            PlayerData.instance.playerID = 3;
            SceneManager.LoadScene("Main Game");
        }
        else if(KullaniciAdi.text == "player3" && Sifre.text == "33333"){
            PlayerData.instance.playerID = 4;
            SceneManager.LoadScene("Main Game");
        }
        else if(KullaniciAdi.text == "player4" && Sifre.text == "44444"){
            PlayerData.instance.playerID = 5;
            SceneManager.LoadScene("Main Game");
        }
    }

}