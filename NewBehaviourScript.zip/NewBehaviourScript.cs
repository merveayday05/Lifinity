using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class NewBehaviourScript : MonoBehaviour
{
    public GameObject prefab;
    private GameObject seviyeprefab;


    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void buton(){
        SceneManager.LoadScene("Main Game");
    }

    public void buton2(){
        seviyeprefab = Instantiate(prefab);
    }
}
